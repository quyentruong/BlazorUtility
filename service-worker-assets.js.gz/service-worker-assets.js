self.assetsManifest = {
  "version": "AjbO3TZb",
  "assets": [
    {
      "hash": "sha256-tZ+pCmlaLHjAOwDoBF+YXLyL6STH1qX6IIdwYqgDEpQ=",
      "url": "BlazorUtility.styles.css"
    },
    {
      "hash": "sha256-SsvWjE7D4ICztUHoipB1y/e+k2mAQn8fEhtcZ9/Ekx0=",
      "url": "_content/CurrieTechnologies.Razor.Clipboard/clipboard.js"
    },
    {
      "hash": "sha256-+x8RcCt100lmsNhUnR+KPLhqanJg6aauVoBFDSm0LB0=",
      "url": "_content/CurrieTechnologies.Razor.Clipboard/clipboard.min.js"
    },
    {
      "hash": "sha256-ZSJicRfSsO+B1xWmpXJ7ou81EIg418GnukAMFJRn3Bc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-EZNMO/azgG7IPa1IlFGwWmLhT64HPPCxhE0H6t+BOiM=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-3pKTLyHO+S4KpvfUJF6OxoGvxm+DT7p4A4SXe2ocNj8=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater.Service/script.min.js"
    },
    {
      "hash": "sha256-CcbCAQysifGy37NQeQFm7ToIaHhq+ULV5MMf7PuLdXs=",
      "url": "_content/Toolbelt.Blazor.PWA.Updater/Toolbelt.Blazor.PWA.Updater.bnjuj6nd91.bundle.scp.css"
    },
    {
      "hash": "sha256-1JqhsKJ4IVwmCgqnroQxCwbymMoTZrntz8KhZPD4CJ0=",
      "url": "_framework/BlazorUtility.kg8kj0wxkk.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-vBJMgYbeYk769TDOiieLojmO+DfePc7AbWS4YH+WzUU=",
      "url": "_framework/CurrieTechnologies.Razor.Clipboard.w9q51qhajg.wasm"
    },
    {
      "hash": "sha256-Lk4yJ+W4Cb0eHgyH23k8fYWXJQVAY4Xi6D3Pwmcmv7s=",
      "url": "_framework/Microsoft.AspNetCore.Components.2j4hx3ztsc.wasm"
    },
    {
      "hash": "sha256-1Wiq2wQ7WCjo9fKkL/AUSia899+a8zbR6QRquH8nWRM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.r053fjs4u7.wasm"
    },
    {
      "hash": "sha256-NJ02RywRr+ncOwK+QAaO5ZAoA0LmD4xf7nfcTI0koi4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.gveadrochg.wasm"
    },
    {
      "hash": "sha256-GjgORQschepw/Fj0uPtkGte5ppoyG7DlGcdsMN/T6eA=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.qwgyqtwzyo.wasm"
    },
    {
      "hash": "sha256-V/8lrAHQfJYsJtV+bKRHL6fmMFhJhAOyoTNfGTbwTdQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.7sm4vp77d1.wasm"
    },
    {
      "hash": "sha256-M/V9DIZ9otM7/qEt+xn3wagkoRiLOf4JMPyDoo6WUM8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.n3roazub70.wasm"
    },
    {
      "hash": "sha256-XQykit2HYxnB0emmOc5bra6XuZq3KgCfazi8kFAErDs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jgtmx19396.wasm"
    },
    {
      "hash": "sha256-R2i8ew2bbTV3imrKO5ixgymXKGC4o3hipV4c/HRO9nA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ngny5qbh3d.wasm"
    },
    {
      "hash": "sha256-wPj/fOeoE7JKOgIYh6OIvl/k3Iw6EPDmmXDjtnQ6rJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g0r86u4i0h.wasm"
    },
    {
      "hash": "sha256-tEtUKTeItXncbYJzaOn0W/BY6wHDdtVCzr0FPuKmN4M=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.o97u05c9gb.wasm"
    },
    {
      "hash": "sha256-u4RUZ6A9cWnQlgCP/S7IxI1Wh8+1iQrhwgBkYE0TEWo=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.lk2ttr0x6l.wasm"
    },
    {
      "hash": "sha256-2z030tfFeYuGlDVd2sbfOcIf506I31apLzlYs3cHxVk=",
      "url": "_framework/Microsoft.Extensions.Http.lcmkci04eo.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-XqqnrZ9xrv52dxXKm7H9svNqwhKI7irYxUnyh95ytoY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.6y555qnzud.wasm"
    },
    {
      "hash": "sha256-QhWV6R3UsAbvd90hOpKEo7wmHVsEGWtliqDxgSwvMrw=",
      "url": "_framework/Microsoft.Extensions.Logging.y3zk4eoscr.wasm"
    },
    {
      "hash": "sha256-iOXmaOTVZZ1tdClSZn+jtjeqS/cl/t/W6ENyhjUBa8c=",
      "url": "_framework/Microsoft.Extensions.Options.snfxgu9l3k.wasm"
    },
    {
      "hash": "sha256-GOr7jc/eCieZrQYoXRn79eLSsesIfFB55wQZIVTSNIY=",
      "url": "_framework/Microsoft.Extensions.Primitives.4dxofymb0o.wasm"
    },
    {
      "hash": "sha256-hbzWuXrlepIqY/y+nQ2ZAFer2/njy1dc+Y4LUaAaL5E=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.p386u0jty9.wasm"
    },
    {
      "hash": "sha256-iZGdoSQHD1PU7bXZFZu5qQCo4LYV5+W54+dZpxtPchE=",
      "url": "_framework/Microsoft.JSInterop.ngmvv3s7g6.wasm"
    },
    {
      "hash": "sha256-n875H5pHTFGROm3aVYc1KKwoy+SUMHCYQE2v6Yu7TtY=",
      "url": "_framework/MudBlazor.hcuz171emz.wasm"
    },
    {
      "hash": "sha256-O5fq+aKAfyry6ws3MUw5XV2+BnAUdeVA3Szq6Dqrxq8=",
      "url": "_framework/System.Collections.Concurrent.tev7izdxov.wasm"
    },
    {
      "hash": "sha256-1+bGK7Y1GjUlQrND68w2LAsGqcvzd1eIBdUtNX264Sk=",
      "url": "_framework/System.Collections.Immutable.bn55ji4amz.wasm"
    },
    {
      "hash": "sha256-GV4RcSJKLUOY0ugGKTG/Idz6ERFiCgSI8MGXj36QAv8=",
      "url": "_framework/System.Collections.NonGeneric.jlmeg697fk.wasm"
    },
    {
      "hash": "sha256-Fvbei1fczipxI9bHdu398NucnHCLPP7omkIp09OKFQ8=",
      "url": "_framework/System.Collections.Specialized.af3v7jsqvp.wasm"
    },
    {
      "hash": "sha256-cAfqJhM06eZY6D9UZmPN6h/TzFFjpioEShBrh9krXjU=",
      "url": "_framework/System.Collections.k7ydxyxyn7.wasm"
    },
    {
      "hash": "sha256-Rn8GW4SWyigec+RbEs5k0PySKTGHE9ZCqM6CdFyCfn4=",
      "url": "_framework/System.ComponentModel.Annotations.qv5uyh0fnm.wasm"
    },
    {
      "hash": "sha256-sQlFRUtuewIhDlSChHALGPMTVM/ZP9A+ruMvvDxgq+I=",
      "url": "_framework/System.ComponentModel.Primitives.1o9ju9rs1s.wasm"
    },
    {
      "hash": "sha256-osogozPulF1G/ArOH7cDN56TaNHDoPX4q7BAWQvq3W8=",
      "url": "_framework/System.ComponentModel.TypeConverter.yoioa3a20n.wasm"
    },
    {
      "hash": "sha256-9USOJqZ7jlkethsedYzZY95qWDtbmWEL6C3MOE2JWwg=",
      "url": "_framework/System.ComponentModel.teirny7gyp.wasm"
    },
    {
      "hash": "sha256-BjdysHI22bXuIahJhg5Uv71lzSy4ViwUZvkGLZpF3zE=",
      "url": "_framework/System.Console.mlfkdcilk1.wasm"
    },
    {
      "hash": "sha256-Rmn//zKYjvlY0uO8Pz5BldkYd6Q5o6JlTGTOtPoBl3Y=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.mo5qengx6p.wasm"
    },
    {
      "hash": "sha256-V5z9/XlJMVOFEDQ+R/mfLxmcykbKzh9+yhFeRdF4kdU=",
      "url": "_framework/System.IO.Pipelines.h68d94scrb.wasm"
    },
    {
      "hash": "sha256-LnldDtMDJ1sbxoIKGAb2YkcD+lDCbtLtQuPD2hVYRl4=",
      "url": "_framework/System.Linq.62in62bg40.wasm"
    },
    {
      "hash": "sha256-15ypsBdAt3w/FHrdeqA2+51z6ld8ce5ORxNSgB3XHaM=",
      "url": "_framework/System.Linq.Expressions.fqelvk9yni.wasm"
    },
    {
      "hash": "sha256-IsFLjKMTNDMKMS7CbzVUu3KiFy4DGRX1EXPJOlAx8vQ=",
      "url": "_framework/System.Memory.qiw6ncvri1.wasm"
    },
    {
      "hash": "sha256-y0nhmOGLmUmbJn6moACSBAvQCcj6F2u24tWWH861PRA=",
      "url": "_framework/System.Net.Http.1xpc4pi49t.wasm"
    },
    {
      "hash": "sha256-bKW53CX4S2Fa7chQh3kKNfVVgA5dRbpw5znbPmbnec4=",
      "url": "_framework/System.Net.Http.Json.4mpz9gl4en.wasm"
    },
    {
      "hash": "sha256-RZU3+AurzUeBWgVjZalkA1jPlfRnehNr+R49gyYTuFI=",
      "url": "_framework/System.Net.Primitives.3uow9zd1kc.wasm"
    },
    {
      "hash": "sha256-zRsqMXREh/PTFg9uY3KgNnGOS00EFxKAYO+0qcyT/Tw=",
      "url": "_framework/System.ObjectModel.fh07eidryx.wasm"
    },
    {
      "hash": "sha256-IgrqD1/oS2vDlSpCRjbBz/h1xpsWYJPr/hHqV7oarIo=",
      "url": "_framework/System.Private.CoreLib.irkn916m04.wasm"
    },
    {
      "hash": "sha256-iRzdy8DS7JxZdyvDx3LIo4UybEkdP+I8ReCgX26OSYY=",
      "url": "_framework/System.Private.Uri.5pcl1q225g.wasm"
    },
    {
      "hash": "sha256-w7B2QuZb3eIKIt6qux87qVoXpYPJKj+3itOMj814bOY=",
      "url": "_framework/System.Runtime.774axrbrk2.wasm"
    },
    {
      "hash": "sha256-r+LQmgoVdHgFKWJvUNAR7HQZAtSw+xvBIQ6siSPsBNM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f4ln4hfftw.wasm"
    },
    {
      "hash": "sha256-Ki9CIBGK1PxgT1lINYYrJXvIS+uhcVV7Po4GxFvD5SM=",
      "url": "_framework/System.Runtime.InteropServices.ebl1t4cqsb.wasm"
    },
    {
      "hash": "sha256-pdi8rUtz97K7+q5y/AgnLY20C4reLdWB+WoFACY2+qM=",
      "url": "_framework/System.Text.Encodings.Web.n5x6mx40rp.wasm"
    },
    {
      "hash": "sha256-BHjkr4+csQaEtNYjAXGjDeaouXDbQ92UMD9RHB1jWh8=",
      "url": "_framework/System.Text.Json.oh8ofeqt8e.wasm"
    },
    {
      "hash": "sha256-jVzJyqu/f1HzhJBnDQ9ENPqdVYUdmnxyr6cFQhq6ugI=",
      "url": "_framework/System.Text.RegularExpressions.j06cmtd76u.wasm"
    },
    {
      "hash": "sha256-24inb9qHwMgt3KIjfomf+IHFhkJlGDDhcK8ivbFO8Z0=",
      "url": "_framework/System.Threading.jmn9lxh1h2.wasm"
    },
    {
      "hash": "sha256-JR9uHwZeWzGLHbZhs4tvobv0QX0mykH6Dw/KbNqFbCA=",
      "url": "_framework/System.v3da086c8u.wasm"
    },
    {
      "hash": "sha256-b5hyAPiYbnbPQQq9Xuq6eh2asCsZ8l+fYzTh6CYCW+8=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.Service.dx2b8fmyxy.wasm"
    },
    {
      "hash": "sha256-lwDrl2MohXlx+9cDwCxxIJDHWc8MyAqx6qYyF6E+DFo=",
      "url": "_framework/Toolbelt.Blazor.PWA.Updater.zh5jq5plq0.wasm"
    },
    {
      "hash": "sha256-koFdCbLOxilbNZS1jswbwGyAmDgq/YezQnGTe45U7ZI=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/pcrNUZIFxvVrfML8zazMdEZ+IB0TdSKqJ6mAPvV+w4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-KIdOjTgqwnRPrs8E/UU8iLB9en7vECQ7k7cYFlvwVKQ=",
      "url": "_framework/dotnet.native.8cvul2x4bx.js"
    },
    {
      "hash": "sha256-qPBZJ2Lryd5Ueb/TlE71hEym4nRVo2dMMFGHpf+hvfo=",
      "url": "_framework/dotnet.native.wyo18588sk.wasm"
    },
    {
      "hash": "sha256-82FoDmY+LsehdN2u8aSGEutGEKXJHcYaSX/3zptbsCw=",
      "url": "_framework/dotnet.runtime.tsg4gsv2hg.js"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-k1g1qt7REjVKwbBsObwUZbU2rmIGIQB93AtINydJ3z8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-IRpic5EAG/OmM1qCcekMVJYwUhMoAiCZjS28BpMfFCE=",
      "url": "index.html"
    },
    {
      "hash": "sha256-6x9UX5nb0xUIijZIZssvZpGrEJzt+tFWokKsGqmveEE=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
